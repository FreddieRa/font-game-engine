"""DEPRECATED - This module is kept here only as a backward compatibility shim
for the old ufoLib.etree module, which was moved to fontemon_blender_addon.fontTools.misc.etree.
Please use the latter instead.
"""
from fontemon_blender_addon.fontTools.misc.etree import *
