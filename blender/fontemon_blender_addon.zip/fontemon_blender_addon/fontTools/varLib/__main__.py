import sys
from fontemon_blender_addon.fontTools.varLib import main


if __name__ == '__main__':
	sys.exit(main())
