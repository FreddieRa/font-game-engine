"""Empty __init__.py file to signal Python this directory is a package."""

from fontemon_blender_addon.fontTools.misc.py23 import *
