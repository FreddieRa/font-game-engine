
class ColorLibError(Exception):
    pass
