from fontemon_blender_addon.fontTools.misc.py23 import *
import sys
from fontemon_blender_addon.fontTools.subset import main


if __name__ == '__main__':
    sys.exit(main())
