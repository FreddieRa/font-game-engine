
class PixelPosition:
  def __init__(self, pixelX: float, pixelY: float) -> None:
      self.pixelX = pixelX
      self.pixelY = pixelY