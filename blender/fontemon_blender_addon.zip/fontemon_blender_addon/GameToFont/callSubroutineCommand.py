def callSubroutineCommand(subroutineNumber: int):
  return f"{subroutineNumber} callsubr\n"