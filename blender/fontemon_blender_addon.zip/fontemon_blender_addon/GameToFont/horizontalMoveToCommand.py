def horizontalMoveToCommand(dx: float):
  return f"{dx} hmoveto\n"