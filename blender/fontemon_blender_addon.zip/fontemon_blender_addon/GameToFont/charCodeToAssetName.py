def charCodeToAssetName(code):
    # type: (str) -> str
    return f"{code}.png"
